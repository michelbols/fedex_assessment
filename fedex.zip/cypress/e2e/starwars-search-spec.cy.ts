/// <reference types="Cypress" />

import { NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR } from "@angular/core/src/view/provider";
import { curry } from "cypress/types/lodash";

describe('Search function star wars search', () => {
  beforeEach(function(){
    // before every test visit the url so it's a clean test.
    cy.visit("http://localhost:4200/");
})

//characters basic flow
it('Finding a valid character displays gender, birthyear, eyecolor and skincolor', () => {
  cy.get('[data-cy="query"]').type("Luke Skywalker");
  cy.get('[data-cy="submit"]').click();
  cy.get('[data-cy="Luke Skywalker-card"]')
  .should('contain.text', 'male')
  .and('contain.text', '19BBY')
  .and('contain.text', 'blue')
  .and('contain.text', 'fair')
   });

it('Not finding a valid character displays the not found message', () => {
   cy.get('[data-cy="query"]').type("cijasdfs");      
   cy.get('[data-cy="submit"]').click();
   cy.get('[data-cy="notFound"').should('have.text', 'Not found.')
   });

//planets basic flow
it('Finding a valid planet displays population, climate and gravity', () => {
    cy.get('#planets').click();    
    cy.get('[data-cy="query"]').type("Tatooine");
    cy.get('[data-cy="submit"]').click();
    cy.get('[data-cy="Tatooine-card"]')
      .should('contain.text', '200000')
      .and('contain.text', 'arid')
      .and('contain.text', '1 standard') 
   });

it('Not finding a valid planet displays the not found message', () => {
    cy.get('#planets').click();    
    cy.get('[data-cy="query"]').type("zzzzzzzzzz");      
    cy.get('[data-cy="submit"]').click();
    cy.get('[data-cy="notFound"').should('have.text', 'Not found.')
   });

//Alternative flows  
it('Identical searches for People and Planet. Planet should give not found', () => {
    cy.get('[data-cy="query"]').type("Luke");  
    cy.get('[data-cy="submit"]').click();
    cy.get('#planets').click();    
    cy.get('[data-cy="submit"]').click();           
    cy.get('[data-cy="notFound"').should('have.text', 'Not found.')
   });

it('Searching for an empty string should clear the results list and not give any results', () => {
    cy.get('[data-cy="query"]').type("Luke");  
    cy.get('[data-cy="submit"]').click();
    cy.get('[data-cy="query"]').clear();
    cy.get('[data-cy="submit"]').click();           
    cy.get('[data-cy="search_results"').should('not.contain', 'Text');
   });

it('Searching for luke with an Enter instead of a click', () => {
    cy.get('[data-cy="query"]').type('Luke{enter}');  
    cy.get('[data-cy="Luke Skywalker-card"]')
    .should('contain.text', 'male')
    .and('contain.text', '19BBY')
    .and('contain.text', 'blue')
    .and('contain.text', 'fair')
   });   

it('Partial search should return multiple results', () => {
    // wait for the rest service to finish, store it in a alias.
    cy.intercept('https://swapi.dev/api/people/?search=A').as('getResults')
    cy.get('[data-cy="query"]').type('A{enter}');  
    // wait for the rest service to finish 
    cy.wait('@getResults')
    //asserting the amount is equal to 11 
    cy.get('.card').its('length').should('eq', 11)
   });


})